//
//  TapAppDelegate.h
//  Tap
//
//  Created by NYU User on 4/7/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
@class View;

@interface TapAppDelegate: NSObject <UIApplicationDelegate> {
	View *view;
	UIWindow *window;
}

@property (nonatomic, retain) IBOutlet UIWindow *window;
@end

